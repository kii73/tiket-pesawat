<?php

// $mysql = new mysqli("localhost", "root", "", "tiket-pesawat");
$mysql = new mysqli("sql300.infinityfree.com", "if0_39935956", "eVlLaf7Vor9", "if0_39935956_tiketpesawat");